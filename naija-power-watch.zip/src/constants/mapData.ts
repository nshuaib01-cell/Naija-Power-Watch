export const NIGERIA_GEOJSON = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": { "name": "Nigeria" },
      "geometry": {
        "type": "Polygon",
        "coordinates": [[
          [3.59, 6.45], [2.67, 6.48], [2.67, 7.85], [2.8, 8.5], [3.61, 9.02], [3.5, 9.8], [3.61, 10.33], [4.2, 11.2], [4.84, 11.74], [5.1, 12.5], [5.34, 13.04], [6.2, 13.1], [6.95, 13.15], [7.5, 12.9], [8.01, 12.88], [8.8, 13.1], [9.42, 13.23], [10.5, 13.2], [11.66, 13.15], [12.5, 12.8], [13.21, 12.58], [14.0, 12.9], [14.68, 13.15], [14.5, 12.5], [14.45, 11.69], [14.1, 11.0], [13.73, 10.44], [13.9, 9.5], [14.03, 8.65], [13.5, 8.0], [13.14, 7.21], [12.8, 6.8], [12.44, 6.37], [11.9, 6.5], [11.41, 6.74], [10.8, 6.7], [10.29, 6.74], [9.8, 6.4], [9.21, 5.86], [8.8, 5.3], [8.51, 4.74], [7.8, 4.5], [7.21, 4.37], [6.5, 4.3], [5.84, 4.37], [5.2, 4.4], [4.51, 4.48], [4.0, 5.5], [3.59, 6.45]
        ]]
      }
    }
  ]
};

export const NEIGHBORS_GEOJSON = {
  "type": "FeatureCollection",
  "features": [
    {
      "type": "Feature",
      "properties": { "name": "Benin" },
      "geometry": { "type": "LineString", "coordinates": [[2.67, 6.48], [1.5, 6.5], [1.5, 12.0], [2.67, 12.0]] }
    },
    {
      "type": "Feature",
      "properties": { "name": "Niger" },
      "geometry": { "type": "LineString", "coordinates": [[5.34, 13.04], [5.34, 15.0], [14.68, 15.0], [14.68, 13.15]] }
    },
    {
      "type": "Feature",
      "properties": { "name": "Chad" },
      "geometry": { "type": "LineString", "coordinates": [[14.68, 13.15], [16.0, 13.15], [16.0, 10.0]] }
    },
    {
      "type": "Feature",
      "properties": { "name": "Cameroon" },
      "geometry": { "type": "LineString", "coordinates": [[14.68, 13.15], [15.5, 12.0], [15.5, 4.0], [8.51, 4.0]] }
    }
  ]
};

export interface OutagePoint {
  id: string;
  city: string;
  lat: number;
  lng: number;
  status: 'ON' | 'OFF' | 'Fluctuating';
  severity: number; // 0 to 1
  outages: number;
  hazards: string[];
}

export const SYNTHETIC_OUTAGES: OutagePoint[] = [
  { id: '1', city: 'Lagos', lat: 6.5244, lng: 3.3792, status: 'OFF', severity: 0.9, outages: 2450, hazards: ['Downed Power Line'] },
  { id: '2', city: 'Abuja', lat: 9.0765, lng: 7.3986, status: 'Fluctuating', severity: 0.6, outages: 1200, hazards: ['Sparking Transformer'] },
  { id: '3', city: 'Kano', lat: 12.0022, lng: 8.5920, status: 'ON', severity: 0.1, outages: 50, hazards: [] },
  { id: '4', city: 'Ibadan', lat: 7.3775, lng: 3.9470, status: 'OFF', severity: 0.8, outages: 1800, hazards: ['Visible Tree Damage'] },
  { id: '5', city: 'Port Harcourt', lat: 4.8156, lng: 7.0498, status: 'Fluctuating', severity: 0.5, outages: 900, hazards: ['Flooding'] },
  { id: '6', city: 'Benin City', lat: 6.3350, lng: 5.6037, status: 'ON', severity: 0.2, outages: 120, hazards: [] },
  { id: '7', city: 'Maiduguri', lat: 11.8311, lng: 13.1509, status: 'OFF', severity: 0.95, outages: 3100, hazards: ['Downed Power Line', 'Flooding'] },
  { id: '8', city: 'Zaria', lat: 11.0691, lng: 7.7138, status: 'ON', severity: 0.15, outages: 80, hazards: [] },
  { id: '9', city: 'Aba', lat: 5.1066, lng: 7.3667, status: 'Fluctuating', severity: 0.7, outages: 1400, hazards: ['Sparking Transformer'] },
  { id: '10', city: 'Jos', lat: 9.8965, lng: 8.8583, status: 'ON', severity: 0.05, outages: 30, hazards: [] },
  { id: '11', city: 'Enugu', lat: 6.4483, lng: 7.5148, status: 'OFF', severity: 0.85, outages: 2100, hazards: ['Downed Power Line'] },
  { id: '12', city: 'Warri', lat: 5.5167, lng: 5.7500, status: 'Fluctuating', severity: 0.4, outages: 600, hazards: [] },
  { id: '13', city: 'Sokoto', lat: 13.0622, lng: 5.2339, status: 'ON', severity: 0.1, outages: 45, hazards: [] },
  { id: '14', city: 'Calabar', lat: 4.9757, lng: 8.3417, status: 'OFF', severity: 0.75, outages: 1650, hazards: ['Flooding'] },
  { id: '15', city: 'Owerri', lat: 5.4850, lng: 7.0350, status: 'ON', severity: 0.2, outages: 150, hazards: [] },
];
