import React, { useState, useEffect } from 'react';
import { Send, MapPin, Clock, Zap, ShieldCheck, AlertTriangle, Lightbulb, WifiOff, MapPinned } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const NIGERIAN_CITIES = [
  'Lagos', 'Abuja', 'Kano', 'Ibadan', 'Port Harcourt', 'Benin City', 'Maiduguri', 'Zaria', 'Aba', 'Jos', 'Ilorin', 'Oyo', 'Enugu', 'Abeokuta', 'Onitsha', 'Warri', 'Sokoto', 'Calabar', 'Owerri', 'Akure'
];

const HAZARDS = [
  'Downed Power Line',
  'Sparking Transformer',
  'Visible Tree Damage',
  'Flooding',
  'None'
];

export default function OutageReporter() {
  const [formData, setFormData] = useState({
    city: '',
    status: 'OFF',
    duration: 2,
    generatorOwned: false,
    latitude: '',
    longitude: '',
    hazards: [] as string[],
    neighborStatus: 'unknown' as 'on' | 'off' | 'unknown',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [isLocating, setIsLocating] = useState(false);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const detectLocation = () => {
    setError(null);
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setFormData(prev => ({
          ...prev,
          latitude: position.coords.latitude.toFixed(6),
          longitude: position.coords.longitude.toFixed(6)
        }));
        setIsLocating(false);
        setError(null);
      },
      (error) => {
        console.error('Error detecting location:', error);
        setError('Unable to retrieve your location. Please ensure GPS is enabled and permissions are granted.');
        setIsLocating(false);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const toggleHazard = (hazard: string) => {
    setError(null);
    setFormData(prev => {
      if (hazard === 'None') {
        return { ...prev, hazards: ['None'] };
      }
      const newHazards = prev.hazards.filter(h => h !== 'None');
      if (newHazards.includes(hazard)) {
        return { ...prev, hazards: newHazards.filter(h => h !== hazard) };
      }
      return { ...prev, hazards: [...newHazards, hazard] };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!formData.latitude || !formData.longitude) {
      setError('GPS coordinates are required. Please use "Detect My Location" before submitting.');
      // Scroll to top of form to show error
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (!formData.city) {
      setError('Please select a city.');
      return;
    }

    setIsSubmitting(true);
    
    const report = {
      ...formData,
      timestamp: new Date().toISOString(),
    };

    if (isOffline) {
      // Queue report locally
      try {
        const queue = JSON.parse(localStorage.getItem('outage_reports_queue') || '[]');
        queue.push(report);
        localStorage.setItem('outage_reports_queue', JSON.stringify(queue));
        
        setTimeout(() => {
          setIsSubmitting(false);
          setShowSuccess(true);
          setError('Offline: Report queued locally. It will sync when you are back online.');
          setTimeout(() => setShowSuccess(false), 5000);
        }, 800);
      } catch (e) {
        setError('Failed to save report locally.');
        setIsSubmitting(false);
      }
    } else {
      // Simulate API call
      console.log('Submitting Outage Report to Google Sheets:', report);
      
      setTimeout(() => {
        setIsSubmitting(false);
        setShowSuccess(true);
        setFormData({
          city: '',
          status: 'OFF',
          duration: 2,
          generatorOwned: false,
          latitude: '',
          longitude: '',
          hazards: [],
          neighborStatus: 'unknown',
        });
        setTimeout(() => setShowSuccess(false), 3000);
      }, 1000);
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-8 md:py-12 px-4 md:px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8 text-center"
      >
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Report an Outage</h2>
        <p className="text-sm text-gray-500">Help us track grid reliability in your area.</p>
      </motion.div>

      <motion.form
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        onSubmit={handleSubmit}
        className="glass-card p-6 md:p-8 space-y-6 md:space-y-8 relative"
      >
        {isOffline && (
          <div className="absolute top-4 right-4 flex items-center gap-2 text-amber-600 bg-amber-50 px-3 py-1 rounded-full text-[10px] font-bold uppercase border border-amber-100 animate-pulse">
            <WifiOff size={12} />
            Offline Mode
          </div>
        )}

        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="p-4 bg-red-50 text-red-700 rounded-xl text-xs font-bold border border-red-100 flex items-center gap-2"
            >
              <AlertTriangle size={14} />
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Geolocation Section */}
        <div className="space-y-4 p-4 bg-gray-50 rounded-2xl border border-gray-100">
          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
              <MapPinned size={16} className="text-nigeria-green" />
              Precise Location
            </label>
            <button
              type="button"
              onClick={detectLocation}
              disabled={isLocating}
              className="text-[10px] font-bold text-nigeria-green hover:text-nigeria-green-dark uppercase flex items-center gap-1 transition-colors"
            >
              {isLocating ? 'Locating...' : 'Detect My Location'}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Latitude</span>
              <input
                type="text"
                readOnly
                value={formData.latitude}
                placeholder="0.000000"
                className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-mono outline-none"
              />
            </div>
            <div className="space-y-1">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Longitude</span>
              <input
                type="text"
                readOnly
                value={formData.longitude}
                placeholder="0.000000"
                className="w-full p-3 bg-white border border-gray-200 rounded-xl text-sm font-mono outline-none"
              />
            </div>
          </div>
        </div>

        {/* City Selection */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
            <MapPin size={16} className="text-nigeria-green" />
            Select City
          </label>
          <select
            required
            value={formData.city}
            onChange={(e) => setFormData({ ...formData, city: e.target.value })}
            className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-nigeria-green focus:border-transparent outline-none transition-all appearance-none cursor-pointer"
          >
            <option value="" disabled>Choose your location...</option>
            {NIGERIAN_CITIES.map(city => (
              <option key={city} value={city}>{city}</option>
            ))}
          </select>
        </div>

        {/* Status Radio Buttons */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
            <Zap size={16} className="text-nigeria-green" />
            Current Power Status
          </label>
          <div className="grid grid-cols-3 gap-4">
            {['ON', 'OFF', 'Fluctuating'].map((status) => (
              <label
                key={status}
                className={cn(
                  "relative flex flex-col items-center justify-center p-4 rounded-xl border-2 cursor-pointer transition-all duration-200",
                  formData.status === status
                    ? "border-nigeria-green bg-nigeria-green-light text-nigeria-green"
                    : "border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200"
                )}
              >
                <input
                  type="radio"
                  name="status"
                  value={status}
                  checked={formData.status === status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="sr-only"
                />
                <span className="text-sm font-bold">{status}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Duration Slider */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
              <Clock size={16} className="text-nigeria-green" />
              Duration of Status
            </label>
            <span className="text-nigeria-green font-bold text-lg">{formData.duration} hrs</span>
          </div>
          <input
            type="range"
            min="0"
            max="24"
            step="0.5"
            value={formData.duration}
            onChange={(e) => setFormData({ ...formData, duration: parseFloat(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-nigeria-green"
          />
          <div className="flex justify-between text-[10px] text-gray-400 font-bold uppercase">
            <span>0 hrs</span>
            <span>12 hrs</span>
            <span>24 hrs</span>
          </div>
        </div>

        {/* Neighbor Status Prompt */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
            <Lightbulb size={16} className="text-nigeria-green" />
            Neighbor Status
          </label>
          <p className="text-xs text-gray-500">Are your streetlights or neighbors' lights on?</p>
          <div className="flex gap-3">
            {[
              { id: 'on', label: 'Yes, Lights On', icon: '💡' },
              { id: 'off', label: 'No, All Dark', icon: '🌑' },
              { id: 'unknown', label: 'Not Sure', icon: '❓' }
            ].map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => setFormData({ ...formData, neighborStatus: option.id as any })}
                className={cn(
                  "flex-1 p-3 rounded-xl border-2 text-xs font-bold transition-all",
                  formData.neighborStatus === option.id
                    ? "border-nigeria-green bg-nigeria-green-light text-nigeria-green"
                    : "border-gray-100 bg-gray-50 text-gray-400 hover:border-gray-200"
                )}
              >
                <div className="text-lg mb-1">{option.icon}</div>
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Hazard Checklist */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-bold text-gray-700 uppercase tracking-wider">
            <AlertTriangle size={16} className="text-amber-500" />
            Infrastructure Hazards
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {HAZARDS.map((hazard) => (
              <label
                key={hazard}
                className={cn(
                  "flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all",
                  formData.hazards.includes(hazard)
                    ? "border-amber-200 bg-amber-50 text-amber-700"
                    : "border-gray-100 bg-gray-50 text-gray-500 hover:border-gray-200"
                )}
              >
                <input
                  type="checkbox"
                  checked={formData.hazards.includes(hazard)}
                  onChange={() => toggleHazard(hazard)}
                  className="sr-only"
                />
                <div className={cn(
                  "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                  formData.hazards.includes(hazard) ? "bg-amber-500 border-amber-500" : "bg-white border-gray-300"
                )}>
                  {formData.hazards.includes(hazard) && <ShieldCheck size={12} className="text-white" />}
                </div>
                <span className="text-xs font-medium">{hazard}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Generator Checkbox */}
        <div className="pt-2">
          <label className="flex items-center gap-3 cursor-pointer group">
            <div className="relative">
              <input
                type="checkbox"
                checked={formData.generatorOwned}
                onChange={(e) => setFormData({ ...formData, generatorOwned: e.target.checked })}
                className="sr-only"
              />
              <div className={cn(
                "w-12 h-6 rounded-full transition-colors duration-200",
                formData.generatorOwned ? "bg-nigeria-green" : "bg-gray-200"
              )} />
              <div className={cn(
                "absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform duration-200",
                formData.generatorOwned && "translate-x-6"
              )} />
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck size={18} className={cn(formData.generatorOwned ? "text-nigeria-green" : "text-gray-400")} />
              <span className="text-sm font-medium text-gray-700">I own a backup generator</span>
            </div>
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className={cn(
            "w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all duration-300 flex items-center justify-center gap-2",
            isSubmitting ? "bg-gray-400 cursor-not-allowed" : "bg-nigeria-green hover:bg-nigeria-green-dark hover:-translate-y-1 active:translate-y-0 shadow-nigeria-green/20"
          )}
        >
          {isSubmitting ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <Send size={18} />
              Submit Report
            </>
          )}
        </button>

        {showSuccess && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 bg-emerald-50 text-emerald-700 rounded-xl text-center text-sm font-medium border border-emerald-100"
          >
            Report submitted successfully! Thank you for your contribution.
          </motion.div>
        )}
      </motion.form>
    </div>
  );
}
