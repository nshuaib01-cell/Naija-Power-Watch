import React, { useEffect, useState } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';
import { 
  Activity, Zap, Globe, AlertCircle, TrendingUp, Map as MapIcon, 
  ChevronRight, ArrowUpRight, ArrowDownRight, Info, BrainCircuit, ShieldAlert, CheckCircle2, XCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { gridMLService, type PredictionResult, type AnomalyAlert, type ReroutingSuggestion } from '../services/mlService';
import GridMap from './GridMap';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Mock Data
const MOCK_OUTAGE_DATA = [
  { time: '00:00', outages: 45 },
  { time: '04:00', outages: 32 },
  { time: '08:00', outages: 68 },
  { time: '12:00', outages: 85 },
  { time: '16:00', outages: 72 },
  { time: '20:00', outages: 54 },
  { time: '23:59', outages: 48 },
];

const REGIONAL_STATS = [
  { region: 'South West', health: 82, status: 'Stable', trend: 'up' },
  { region: 'North Central', health: 65, status: 'Fluctuating', trend: 'down' },
  { region: 'South South', health: 78, status: 'Stable', trend: 'up' },
  { region: 'North West', health: 42, status: 'Critical', trend: 'down' },
];

export default function GridDashboard() {
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isTraining, setIsTraining] = useState(true);
  const [activeAnomaly, setActiveAnomaly] = useState<AnomalyAlert | null>(null);
  const [activeReroute, setActiveReroute] = useState<ReroutingSuggestion | null>(null);
  const gridHealth = 74;

  useEffect(() => {
    const initML = async () => {
      await gridMLService.trainModel();
      setIsTraining(false);
      
      // Initial prediction based on current mock state
      const result = gridMLService.predictRisk({
        city: 'Lagos',
        status: 'Fluctuating',
        duration: 4,
        generatorOwned: true,
        activeOutages: 1284,
        totalLoadMW: 4820
      });
      setPrediction(result);

      // Simulate an anomaly after 3 seconds for the demo
      setTimeout(() => {
        const anomalyResult = gridMLService.predictRisk({
          city: 'Abuja',
          status: 'ON',
          duration: 1,
          generatorOwned: false,
          activeOutages: 500,
          totalLoadMW: 7200 // Sudden spike
        });
        if (anomalyResult.anomaly) {
          setActiveAnomaly(anomalyResult.anomaly);
          if (anomalyResult.reroute) {
            setActiveReroute(anomalyResult.reroute);
          }
        }
      }, 3000);
    };

    initML();
  }, []);

  const handleAnomalyAction = (status: 'CONFIRMED' | 'REJECTED') => {
    if (!activeAnomaly) return;
    setActiveAnomaly({ ...activeAnomaly, status });
    
    // Clear after a delay
    setTimeout(() => {
      setActiveAnomaly(null);
      if (status === 'REJECTED') setActiveReroute(null);
    }, 2000);
  };

  const simulateRandomEvent = () => {
    const cities = ['Lagos', 'Abuja', 'Kano', 'Ibadan', 'Port Harcourt'];
    const city = cities[Math.floor(Math.random() * cities.length)];
    const isAnomaly = Math.random() > 0.7;
    
    const testState = {
      city,
      status: isAnomaly ? 'Fluctuating' : 'ON' as any,
      duration: Math.random() * 5,
      generatorOwned: Math.random() > 0.5,
      activeOutages: isAnomaly ? 1500 + Math.random() * 1000 : 100 + Math.random() * 400,
      totalLoadMW: isAnomaly ? 6500 + Math.random() * 1000 : 3000 + Math.random() * 1500
    };

    const result = gridMLService.predictRisk(testState);
    setPrediction(result);
    
    if (result.anomaly) {
      setActiveAnomaly(result.anomaly);
      if (result.reroute) setActiveReroute(result.reroute);
    } else {
      // If no natural anomaly, force one occasionally for testing
      if (Math.random() > 0.8) {
        const forcedAnomaly = {
          id: Math.random().toString(36).substr(2, 9),
          city,
          currentLoad: testState.totalLoadMW,
          rollingMean: 4000,
          deviationSigma: 2.8,
          timestamp: new Date().toLocaleTimeString(),
          status: 'PENDING' as any
        };
        setActiveAnomaly(forcedAnomaly);
        setActiveReroute({
          source: 'Lagos_Main',
          target: 'Epe_Sub',
          faultyNode: city + '_Sub',
          alternativePath: ['Lagos_Main', 'Victoria_Island_Sub', 'Lekki_Sub', 'Epe_Sub'],
          status: 'SUCCESS',
          capacityMW: 1200
        });
      }
    }
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto space-y-6 md:space-y-8">
      {/* Anomaly Alert (HITL) */}
      <AnimatePresence>
        {activeAnomaly && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className={cn(
              "fixed top-6 right-6 z-50 w-full max-w-md overflow-hidden rounded-2xl shadow-2xl border",
              activeAnomaly.status === 'PENDING' ? "bg-amber-50 border-amber-200" :
              activeAnomaly.status === 'CONFIRMED' ? "bg-emerald-50 border-emerald-200" : "bg-gray-50 border-gray-200"
            )}
          >
            <div className="p-5">
              <div className="flex items-start gap-4">
                <div className={cn(
                  "p-2 rounded-xl",
                  activeAnomaly.status === 'PENDING' ? "bg-amber-100 text-amber-600" :
                  activeAnomaly.status === 'CONFIRMED' ? "bg-emerald-100 text-emerald-600" : "bg-gray-100 text-gray-600"
                )}>
                  {activeAnomaly.status === 'PENDING' ? <AlertCircle size={24} /> :
                   activeAnomaly.status === 'CONFIRMED' ? <CheckCircle2 size={24} /> : <XCircle size={24} />}
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-black text-gray-900 uppercase tracking-tight">
                    {activeAnomaly.status === 'PENDING' ? 'Anomaly Detected' : 
                     activeAnomaly.status === 'CONFIRMED' ? 'Anomaly Confirmed' : 'Anomaly Rejected'}
                  </h3>
                  <p className="text-xs text-gray-600 mt-1">
                    Sudden load spike in <span className="font-bold">{activeAnomaly.city}</span> detected by sliding window.
                  </p>
                  
                  {activeAnomaly.status === 'PENDING' && (
                    <div className="mt-4 bg-white/50 rounded-xl p-3 border border-amber-100">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-[10px] font-bold text-gray-400 uppercase">Current Load</div>
                          <div className="text-sm font-black text-gray-900">{activeAnomaly.currentLoad} MW</div>
                        </div>
                        <div>
                          <div className="text-[10px] font-bold text-gray-400 uppercase">Deviation</div>
                          <div className="text-sm font-black text-amber-600">+{activeAnomaly.deviationSigma}σ</div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activeAnomaly.status === 'CONFIRMED' && activeReroute && (
                    <div className="mt-3 p-3 bg-emerald-100/50 rounded-xl border border-emerald-100">
                      <div className="text-[10px] font-bold text-emerald-700 uppercase mb-2">Graph-Based Reroute Suggestion</div>
                      <div className="flex items-center gap-2 text-xs font-bold text-emerald-800">
                        {activeReroute.alternativePath.map((node, idx) => (
                          <React.Fragment key={node}>
                            <span>{node.split('_')[0]}</span>
                            {idx < activeReroute.alternativePath.length - 1 && <ChevronRight size={12} />}
                          </React.Fragment>
                        ))}
                      </div>
                      <div className="mt-2 text-[10px] text-emerald-600">
                        Capacity: <span className="font-bold">{activeReroute.capacityMW} MW</span> | Dijkstra Shortest Path
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {activeAnomaly.status === 'PENDING' && (
                <div className="mt-5 flex items-center gap-3">
                  <button 
                    onClick={() => handleAnomalyAction('CONFIRMED')}
                    className="flex-1 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold py-2.5 rounded-xl shadow-lg shadow-amber-600/20 transition-all"
                  >
                    Confirm & Reroute
                  </button>
                  <button 
                    onClick={() => handleAnomalyAction('REJECTED')}
                    className="px-4 py-2.5 bg-white border border-gray-200 text-gray-600 text-xs font-bold rounded-xl hover:bg-gray-50 transition-all"
                  >
                    Dismiss
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Section */}
      <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            {isTraining && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-amber-100 text-amber-700 text-[10px] font-bold uppercase rounded animate-pulse">
                <BrainCircuit size={10} />
                Training ML Model...
              </div>
            )}
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 tracking-tight">Grid Dashboard</h2>
          <p className="text-sm text-gray-500 mt-1">Real-time monitoring of Nigeria's national power grid.</p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={simulateRandomEvent}
            className="px-4 py-2 bg-white border border-gray-200 text-gray-600 text-xs font-bold rounded-xl hover:bg-gray-50 transition-all flex items-center gap-2 shadow-sm"
          >
            <Activity size={14} />
            Simulate Event
          </button>
          <div className="flex items-center gap-3 bg-white p-1.5 rounded-xl border border-gray-100 shadow-sm self-start sm:self-auto">
            <div className="px-3 py-1.5 bg-nigeria-green-light rounded-lg flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-nigeria-green animate-pulse" />
              <span className="text-[10px] font-bold text-nigeria-green uppercase tracking-wider">Live</span>
            </div>
            <span className="text-[10px] text-gray-400 font-medium pr-3">Sync: Just now</span>
          </div>
        </div>
      </header>

      {/* ML Predictive Analytics Section */}
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative overflow-hidden rounded-2xl md:rounded-3xl bg-gray-900 p-6 md:p-8 text-white shadow-xl"
      >
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-nigeria-green/20 blur-[100px] rounded-full" />
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-blue-500/10 blur-[100px] rounded-full" />

        <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8 items-center">
          <div className="lg:col-span-4 flex flex-col items-center lg:items-start text-center lg:text-left">
            <div className="flex items-center gap-2 text-nigeria-green font-bold text-[10px] md:text-xs uppercase tracking-widest mb-3">
              <BrainCircuit size={16} />
              AI Predictive Engine
            </div>
            <h3 className="text-2xl md:text-4xl font-black mb-2">Grid Collapse Risk</h3>
            <p className="text-gray-400 text-xs max-w-xs">
              Our RandomForest model analyzes patterns to predict potential grid failures.
            </p>
            
            <div className="mt-6 md:mt-8 flex items-center gap-4 md:gap-6">
              <div className="text-center">
                <div className={cn(
                  "text-3xl md:text-5xl font-black mb-1",
                  prediction?.riskLevel === 'LOW' ? "text-emerald-400" :
                  prediction?.riskLevel === 'MEDIUM' ? "text-amber-400" :
                  prediction?.riskLevel === 'HIGH' ? "text-orange-400" : "text-red-500"
                )}>
                  {isTraining ? '--' : `${prediction?.riskPercentage}%`}
                </div>
                <div className="text-[9px] md:text-[10px] font-bold text-gray-500 uppercase tracking-widest">Probability</div>
              </div>
              <div className="h-10 md:h-12 w-px bg-gray-800" />
              <div className="text-center">
                <div className={cn(
                  "text-lg md:text-xl font-bold mb-1",
                  prediction?.riskLevel === 'LOW' ? "text-emerald-400" :
                  prediction?.riskLevel === 'MEDIUM' ? "text-amber-400" :
                  prediction?.riskLevel === 'HIGH' ? "text-orange-400" : "text-red-500"
                )}>
                  {isTraining ? '...' : prediction?.riskLevel}
                </div>
                <div className="text-[9px] md:text-[10px] font-bold text-gray-500 uppercase tracking-widest">Risk Level</div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-8">
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl md:rounded-2xl p-4 md:p-6">
              <h4 className="flex items-center gap-2 text-[10px] md:text-xs font-bold text-gray-300 uppercase tracking-wider mb-3 md:mb-4">
                <ShieldAlert size={14} className="text-nigeria-green" />
                Actionable Insights
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
                {isTraining ? (
                  Array(4).fill(0).map((_, i) => (
                    <div key={i} className="h-12 bg-white/5 animate-pulse rounded-xl" />
                  ))
                ) : (
                  prediction?.recommendations.map((rec, idx) => (
                    <motion.div
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      key={idx}
                      className="flex items-start gap-3 p-3 bg-white/5 rounded-xl border border-white/5 hover:border-nigeria-green/30 transition-colors"
                    >
                      <CheckCircle2 size={16} className="text-nigeria-green mt-0.5 shrink-0" />
                      <span className="text-xs text-gray-300 leading-relaxed">{rec}</span>
                    </motion.div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Grid Health Gauge */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card p-4 md:p-6 flex flex-col items-center justify-center text-center"
        >
          <div className="relative w-32 h-32 md:w-40 md:h-40 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="56"
                fill="transparent"
                stroke="#f3f4f6"
                strokeWidth="10"
                className="md:cx-80 md:cy-80 md:r-70 md:stroke-width-12"
              />
              <motion.circle
                cx="64"
                cy="64"
                r="56"
                fill="transparent"
                stroke="#008753"
                strokeWidth="10"
                strokeDasharray={352}
                initial={{ strokeDashoffset: 352 }}
                animate={{ strokeDashoffset: 352 - (352 * gridHealth) / 100 }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                strokeLinecap="round"
                className="md:cx-80 md:cy-80 md:r-70 md:stroke-width-12"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-3xl md:text-4xl font-black text-gray-900">{gridHealth}%</span>
              <span className="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest">Health</span>
            </div>
          </div>
          <div className="mt-3 md:mt-4">
            <h3 className="text-sm md:text-base font-bold text-gray-800">Grid Health</h3>
            <p className="text-[10px] md:text-xs text-gray-500 mt-1">Overall stability index.</p>
          </div>
        </motion.div>

        {/* Quick Stats */}
        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
          <StatCard 
            title="Active Outages" 
            value="1,284" 
            trend="+12%" 
            trendType="down" 
            icon={AlertCircle} 
            color="text-amber-500"
            bgColor="bg-amber-50"
          />
          <StatCard 
            title="Total Load" 
            value="4,820 MW" 
            trend="-2.4%" 
            trendType="up" 
            icon={Zap} 
            color="text-nigeria-green"
            bgColor="bg-nigeria-green-light"
          />
          <StatCard 
            title="Reporting Nodes" 
            value="18,492" 
            trend="+45" 
            trendType="up" 
            icon={Globe} 
            color="text-blue-500"
            bgColor="bg-blue-50"
          />
          <StatCard 
            title="Avg. Restoration" 
            value="4.2 hrs" 
            trend="-15%" 
            trendType="up" 
            icon={Activity} 
            color="text-purple-500"
            bgColor="bg-purple-50"
          />
        </div>
      </div>

      {/* Charts & Map Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Feature Importance Chart */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-6"
        >
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gray-50 rounded-lg">
                <BrainCircuit size={20} className="text-nigeria-green" />
              </div>
              <h3 className="font-bold text-gray-900">Risk Factors (ML Importance)</h3>
            </div>
            <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              Top Contributors
            </div>
          </div>
          <div className="h-[300px] w-full">
            {isTraining ? (
              <div className="h-full w-full flex items-center justify-center bg-gray-50 rounded-xl animate-pulse">
                <span className="text-xs text-gray-400 font-bold">Analyzing Patterns...</span>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  layout="vertical"
                  data={prediction?.featureImportance}
                  margin={{ left: 40, right: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f3f4f6" />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fill: '#4b5563', fontWeight: 600 }}
                    width={100}
                  />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#008753" 
                    strokeWidth={4} 
                    dot={{ r: 6, fill: '#008753', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 8 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </motion.div>

        {/* Time Series Chart */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card p-6"
        >
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gray-50 rounded-lg">
                <TrendingUp size={20} className="text-gray-400" />
              </div>
              <h3 className="font-bold text-gray-900">Outage Trends (24h)</h3>
            </div>
            <button className="text-xs font-bold text-nigeria-green hover:underline flex items-center gap-1">
              Full Report <ChevronRight size={14} />
            </button>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_OUTAGE_DATA}>
                <defs>
                  <linearGradient id="colorOutages" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#008753" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#008753" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis 
                  dataKey="time" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#9ca3af', fontWeight: 600 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#9ca3af', fontWeight: 600 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '12px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    fontSize: '12px'
                  }} 
                />
                <Area 
                  type="monotone" 
                  dataKey="outages" 
                  stroke="#008753" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorOutages)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      {/* Interactive Map Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <GridMap />
      </motion.div>

      {/* Regional Table */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-card overflow-hidden"
      >
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold text-gray-900">Regional Performance</h3>
          <Info size={16} className="text-gray-300" />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50">
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Region</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Grid Health</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Current Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-gray-400 uppercase tracking-wider">Trend</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {REGIONAL_STATS.map((stat, idx) => (
                <tr key={idx} className="hover:bg-gray-50/50 transition-colors cursor-pointer group">
                  <td className="px-6 py-4 font-bold text-gray-700">{stat.region}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-1.5 bg-gray-100 rounded-full max-w-[100px] overflow-hidden">
                        <div 
                          className={cn(
                            "h-full rounded-full",
                            stat.health > 70 ? "bg-nigeria-green" : stat.health > 50 ? "bg-amber-500" : "bg-red-500"
                          )}
                          style={{ width: `${stat.health}%` }}
                        />
                      </div>
                      <span className="text-xs font-bold text-gray-500">{stat.health}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-tighter",
                      stat.status === 'Stable' ? "bg-emerald-100 text-emerald-700" : 
                      stat.status === 'Fluctuating' ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"
                    )}>
                      {stat.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    {stat.trend === 'up' ? (
                      <div className="flex items-center gap-1 text-emerald-600 font-bold text-xs">
                        <ArrowUpRight size={14} /> Improving
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 text-red-600 font-bold text-xs">
                        <ArrowDownRight size={14} /> Declining
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

function StatCard({ title, value, trend, trendType, icon: Icon, color, bgColor }: any) {
  return (
    <motion.div 
      whileHover={{ y: -2 }}
      className="glass-card p-4 md:p-6 flex items-start justify-between"
    >
      <div>
        <p className="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">{title}</p>
        <h4 className="text-xl md:text-2xl font-black text-gray-900">{value}</h4>
        <div className={cn(
          "mt-1.5 md:mt-2 flex items-center gap-1 text-[10px] md:text-xs font-bold",
          trendType === 'up' ? "text-emerald-600" : "text-amber-600"
        )}>
          {trendType === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
          {trend}
        </div>
      </div>
      <div className={cn("p-2 md:p-3 rounded-lg md:rounded-xl", bgColor)}>
        <Icon size={20} className={color} />
      </div>
    </motion.div>
  );
}
