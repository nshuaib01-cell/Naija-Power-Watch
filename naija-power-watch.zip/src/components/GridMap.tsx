import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { SYNTHETIC_OUTAGES, OutagePoint, NIGERIA_GEOJSON, NEIGHBORS_GEOJSON } from '../constants/mapData';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Zap, MapPin, Info } from 'lucide-react';

export default function GridMap() {
  const svgRef = useRef<SVGSVGElement>(null);
  const gOutlineRef = useRef<SVGGElement>(null);
  const gNeighborsRef = useRef<SVGGElement>(null);
  const gGridRef = useRef<SVGGElement>(null);
  const gPointsRef = useRef<SVGGElement>(null);
  const [selectedPoint, setSelectedPoint] = useState<OutagePoint | null>(null);
  const [hoveredPoint, setHoveredPoint] = useState<OutagePoint | null>(null);

  // Memoize projection to avoid recalculating on every render
  const projection = React.useMemo(() => {
    return d3.geoMercator()
      .center([8.6753, 9.0820])
      .scale(3000)
      .translate([400, 300]); // Half of 800x600
  }, []);

  // Memoize path generator
  const pathGenerator = React.useMemo(() => {
    return d3.geoPath().projection(projection);
  }, [projection]);

  // Memoize grid data
  const gridData = React.useMemo(() => {
    return d3.range(3, 16, 1).flatMap(lng => 
      d3.range(4, 15, 1).map(lat => ({ lat, lng }))
    );
  }, []);

  // Initial setup for static layers
  useEffect(() => {
    if (!gGridRef.current || !gOutlineRef.current || !gNeighborsRef.current) return;
    
    // Draw Neighbors (Thin lines)
    const gNeighbors = d3.select(gNeighborsRef.current);
    gNeighbors.selectAll('.neighbor-line')
      .data(NEIGHBORS_GEOJSON.features)
      .join('path')
      .attr('class', 'neighbor-line')
      .attr('d', pathGenerator as any)
      .attr('fill', 'none')
      .attr('stroke', '#e5e7eb')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '4,4');

    // Draw Outline (Thick black line like the image)
    const gOutline = d3.select(gOutlineRef.current);
    gOutline.selectAll('.nigeria-outline')
      .data(NIGERIA_GEOJSON.features)
      .join('path')
      .attr('class', 'nigeria-outline')
      .attr('d', pathGenerator as any)
      .attr('fill', '#fff')
      .attr('stroke', '#111827')
      .attr('stroke-width', 3)
      .attr('stroke-linejoin', 'round');

    // Draw Grid
    const gGrid = d3.select(gGridRef.current);
    gGrid.selectAll('.grid-dot')
      .data(gridData)
      .join('circle')
      .attr('class', 'grid-dot')
      .attr('cx', (d: any) => projection([d.lng, d.lat])![0])
      .attr('cy', (d: any) => projection([d.lng, d.lat])![1])
      .attr('r', 1)
      .attr('fill', '#f3f4f6');
  }, [projection, gridData, pathGenerator]);

  // Dynamic update for outage points
  useEffect(() => {
    if (!gPointsRef.current) return;

    const gPoints = d3.select(gPointsRef.current);

    // Optimized Data Join for Outage Points
    const points = gPoints.selectAll<SVGGElement, OutagePoint>('.outage-point')
      .data(SYNTHETIC_OUTAGES, d => d.id)
      .join(
        enter => {
          const g = enter.append('g')
            .attr('class', 'outage-point')
            .style('cursor', 'pointer')
            .on('mouseenter', (event, d) => setHoveredPoint(d))
            .on('mouseleave', () => setHoveredPoint(null))
            .on('click', (event, d) => setSelectedPoint(d));

          // Pulse circle (only for high severity)
          g.append('circle')
            .attr('class', 'pulse-circle')
            .attr('opacity', 0.2);

          // Main dot
          g.append('circle')
            .attr('class', 'main-dot')
            .attr('stroke', '#fff')
            .attr('stroke-width', 2);

          // Label
          g.append('text')
            .attr('class', 'city-label')
            .attr('font-size', '10px')
            .attr('font-weight', 'bold')
            .attr('fill', '#374151')
            .style('pointer-events', 'none');

          return g;
        }
      );

    // Update existing and new elements
    points.attr('transform', d => {
      const [x, y] = projection([d.lng, d.lat])!;
      return `translate(${x},${y})`;
    });

    // Pulse
    points.select('.pulse-circle')
      .style('display', d => d.severity > 0.7 ? 'block' : 'none')
      .attr('fill', d => d.status === 'OFF' ? '#ef4444' : '#f59e0b')
      .attr('class', d => d.severity > 0.7 ? 'pulse-circle map-pulse' : 'pulse-circle');

    // Main Dot
    points.select('.main-dot')
      .attr('r', d => 4 + d.severity * 6)
      .attr('fill', d => 
        d.status === 'OFF' ? '#ef4444' : 
        d.status === 'Fluctuating' ? '#f59e0b' : '#10b981'
      );

    // Label
    points.select('.city-label')
      .style('display', d => (d.severity > 0.5 || d.city === 'Lagos' || d.city === 'Abuja') ? 'block' : 'none')
      .attr('x', 10)
      .attr('y', 4)
      .text(d => d.city);

  }, [projection]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Map Container */}
      <div className="lg:col-span-2 bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden relative min-h-[500px]">
        {/* ... (Header and Legend remain the same) */}
        <div className="absolute top-6 left-6 z-10">
          <h3 className="text-lg font-black text-gray-900 flex items-center gap-2">
            <MapPin size={20} className="text-nigeria-green" />
            Interactive Outage Map
          </h3>
          <p className="text-xs text-gray-500">Live geographic distribution of grid status.</p>
        </div>

        <div className="absolute bottom-6 left-6 z-10 flex flex-col gap-2">
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase text-gray-400">
            <div className="w-2 h-2 rounded-full bg-red-500" /> Outage (OFF)
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase text-gray-400">
            <div className="w-2 h-2 rounded-full bg-amber-500" /> Fluctuating
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold uppercase text-gray-400">
            <div className="w-2 h-2 rounded-full bg-emerald-500" /> Stable (ON)
          </div>
        </div>

        <svg
          ref={svgRef}
          viewBox="0 0 800 600"
          className="w-full h-full"
          style={{ background: '#fafafa' }}
        >
          <g ref={gNeighborsRef} className="neighbors" />
          <g ref={gOutlineRef} className="map-outline" />
          <g ref={gGridRef} className="static-grid" />
          <g ref={gPointsRef} className="dynamic-points" />
        </svg>


        {/* Hover Tooltip */}
        <AnimatePresence>
          {hoveredPoint && !selectedPoint && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="absolute pointer-events-none bg-gray-900 text-white p-3 rounded-xl shadow-xl text-xs z-20"
              style={{
                left: '50%',
                bottom: '20px',
                transform: 'translateX(-50%)'
              }}
            >
              <div className="font-black mb-1">{hoveredPoint.city}</div>
              <div className="flex items-center gap-2 opacity-80">
                <Zap size={12} />
                {hoveredPoint.outages.toLocaleString()} active outages
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Details Sidebar */}
      <div className="space-y-6">
        <AnimatePresence mode="wait">
          {selectedPoint ? (
            <motion.div
              key={selectedPoint.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 space-y-6"
            >
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-2xl font-black text-gray-900">{selectedPoint.city}</h4>
                  <div className="text-xs text-gray-400 font-bold uppercase mt-1">Detailed Node Analysis</div>
                </div>
                <button 
                  onClick={() => setSelectedPoint(null)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <Info size={20} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-2xl">
                  <div className="text-[10px] font-bold text-gray-400 uppercase mb-1">Status</div>
                  <div className={cn(
                    "text-sm font-black",
                    selectedPoint.status === 'OFF' ? "text-red-600" : 
                    selectedPoint.status === 'Fluctuating' ? "text-amber-600" : "text-emerald-600"
                  )}>
                    {selectedPoint.status}
                  </div>
                </div>
                <div className="p-4 bg-gray-50 rounded-2xl">
                  <div className="text-[10px] font-bold text-gray-400 uppercase mb-1">Severity</div>
                  <div className="text-sm font-black text-gray-900">
                    {(selectedPoint.severity * 100).toFixed(0)}%
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="text-[10px] font-bold text-gray-400 uppercase">Active Hazards</div>
                {selectedPoint.hazards.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {selectedPoint.hazards.map(hazard => (
                      <div key={hazard} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg text-xs font-bold border border-amber-100">
                        <AlertTriangle size={12} />
                        {hazard}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs text-gray-400 italic">No active hazards reported.</div>
                )}
              </div>

              <div className="pt-4 border-t border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xs font-bold text-gray-500">Outage Intensity</span>
                  <span className="text-xs font-black text-gray-900">{selectedPoint.outages.toLocaleString()}</span>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${selectedPoint.severity * 100}%` }}
                    className={cn(
                      "h-full rounded-full",
                      selectedPoint.status === 'OFF' ? "bg-red-500" : "bg-amber-500"
                    )}
                  />
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gray-50 rounded-3xl border border-dashed border-gray-200 p-8 text-center flex flex-col items-center justify-center min-h-[300px]"
            >
              <div className="w-12 h-12 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4">
                <MapPin className="text-gray-300" />
              </div>
              <h4 className="text-sm font-bold text-gray-900">Select a Node</h4>
              <p className="text-xs text-gray-400 mt-1 max-w-[200px]">Click on a map marker to view detailed regional grid analytics.</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Stats Bento */}
        <div className="bg-nigeria-green rounded-3xl p-6 text-white shadow-lg shadow-nigeria-green/20">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={16} />
            <span className="text-[10px] font-bold uppercase tracking-wider">National Summary</span>
          </div>
          <div className="space-y-4">
            <div>
              <div className="text-3xl font-black">15,402</div>
              <div className="text-[10px] font-bold opacity-60 uppercase">Total Active Outages</div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
              <div>
                <div className="text-lg font-black">4</div>
                <div className="text-[10px] font-bold opacity-60 uppercase">Critical Cities</div>
              </div>
              <div>
                <div className="text-lg font-black">82%</div>
                <div className="text-[10px] font-bold opacity-60 uppercase">Grid Stability</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
