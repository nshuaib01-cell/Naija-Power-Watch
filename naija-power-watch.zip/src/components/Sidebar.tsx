import React from 'react';
import { LayoutDashboard, AlertTriangle, Menu, X, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface SidebarProps {
  activeView: 'dashboard' | 'reporter';
  onViewChange: (view: 'dashboard' | 'reporter') => void;
}

export default function Sidebar({ activeView, onViewChange }: SidebarProps) {
  const [isOpen, setIsOpen] = React.useState(true);

  const menuItems = [
    { id: 'dashboard', label: 'Grid Dashboard', icon: LayoutDashboard },
    { id: 'reporter', label: 'Outage Reporter', icon: AlertTriangle },
  ] as const;

  return (
    <>
      {/* Mobile Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-lg shadow-md text-nigeria-green"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      <motion.aside
        initial={false}
        animate={{ width: isOpen ? 260 : 80 }}
        className={cn(
          "fixed left-0 top-0 h-screen bg-white border-r border-gray-200 z-40 flex flex-col transition-all duration-300",
          !isOpen && "items-center"
        )}
      >
        {/* Logo Section */}
        <div className={cn("p-6 flex items-center gap-3", !isOpen && "justify-center")}>
          <div className="w-10 h-10 bg-nigeria-green rounded-xl flex items-center justify-center text-white shrink-0">
            <Zap size={24} fill="currentColor" />
          </div>
          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="overflow-hidden whitespace-nowrap"
              >
                <h1 className="font-bold text-lg text-gray-900 leading-tight">NaijaGrid</h1>
                <p className="text-xs text-nigeria-green font-medium">Smart Monitoring</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id)}
                className={cn(
                  "w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 group",
                  isActive
                    ? "bg-nigeria-green text-white shadow-lg shadow-nigeria-green/20"
                    : "text-gray-500 hover:bg-nigeria-green-light hover:text-nigeria-green"
                )}
              >
                <Icon size={22} className={cn("shrink-0", !isActive && "group-hover:scale-110 transition-transform")} />
                <AnimatePresence>
                  {isOpen && (
                    <motion.span
                      initial={{ opacity: 0, width: 0 }}
                      animate={{ opacity: 1, width: 'auto' }}
                      exit={{ opacity: 0, width: 0 }}
                      className="font-medium whitespace-nowrap overflow-hidden"
                    >
                      {item.label}
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            );
          })}
        </nav>

        {/* Footer Info */}
        <div className={cn("p-6 border-t border-gray-100", !isOpen && "hidden")}>
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-[10px] uppercase tracking-wider text-gray-400 font-bold mb-1">System Status</p>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-medium text-gray-600">All Systems Operational</span>
            </div>
          </div>
        </div>
      </motion.aside>
    </>
  );
}
